export const handleUpdateData = () => {
  window.location.reload()
}
